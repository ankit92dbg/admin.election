<ul class="nav nav-underline">
                        <li class="nav-item" onclick="showTab('#searchVoter','.inner-tab-data')">
                          <a class="nav-link active" aria-current="page" href="javascript:void(0);">Search</a>
                        </li>
                        <li class="nav-item" onclick="showTab('#agewise','.inner-tab-data')">
                          <a class="nav-link" href="javascript:void(0);">Agewise List</a>
                        </li>
                        <li class="nav-item" onclick="showTab('#family','.inner-tab-data')">
                          <a class="nav-link" href="javascript:void(0);">Family Report</a>
                        </li>
                        <li class="nav-item" onclick="showTab('#report_2','.inner-tab-data')">
                          <a class="nav-link" href="javascript:void(0);">Family Head Report</a>
                        </li>
                        <li class="nav-item" onclick="showTab('#report_2','.inner-tab-data')">
                          <a class="nav-link" href="javascript:void(0);">Double Name List</a>
                        </li>
                        <li class="nav-item" onclick="showTab('#report_2','.inner-tab-data')">
                          <a class="nav-link" href="javascript:void(0);">Married Women Report</a>
                        </li>
                        <li class="nav-item" onclick="showTab('#report_2','.inner-tab-data')">
                          <a class="nav-link" href="javascript:void(0);">Single Voter List</a>
                        </li>
                        <li class="nav-item" onclick="showTab('#report_2','.inner-tab-data')">
                          <a class="nav-link" href="javascript:void(0);">Address Wise List</a>
                        </li>
                        <li class="nav-item" onclick="showTab('#report_2','.inner-tab-data')">
                          <a class="nav-link" href="javascript:void(0);">Surname Report</a>
                        </li>
                      </ul>