<?php
$un= "praveen_ankit";
$dn = "praveen_election";
$host = "localhost";
$psw ="ankit@321";

$conn = mysqli_connect($host,$un,$psw,$dn);
mysqli_set_charset($conn, 'utf8');
    
?>